# kcquant

This package enables you to perform exploratory data analysis on images, as well as
easily quantize the colors of an image to be used for machine learning applications.

To install this package, use

```bash
pip install kcquant
```

![image](https://raw.githubusercontent.com/kbkus/kcquant/main/kcquant/Images/get_colors.png?token=AME4SBXQAWML7AMDXM34FMDAGRBT2)
