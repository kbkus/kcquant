# kcquant

This package enables you to perform exploratory data analysis on images, as well as
easily quantize the colors of an image to be used for machine learning applications.

To install this package, use

```bash
pip install kcquant
```

![image](https://github.com/kbkus/kcquant/blob/main/kcquant/Images/get_colors.png?raw=True).
